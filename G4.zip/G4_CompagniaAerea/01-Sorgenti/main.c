#include <stdio.h>
#include "CompagniaAerea.h"

int main() {
    F_gestione_compagnia_aerea();
    return 0;
}
